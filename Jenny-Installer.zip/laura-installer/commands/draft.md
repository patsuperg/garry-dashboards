# /draft — Draft TFE content in Laura's voice

When Laura runs `/draft`, do this:

1. **Ask what she needs drafted.** If she didn't already say, ask:
   > "What are we drafting? Social post, email, DM, sales copy, podcast intro — something else?"

2. **Get the missing context with ONE follow-up at a time.** Don't dump 5 questions. Pick the most important one first:
   - For social: "What's the angle, and which platform?"
   - For email: "Is this a check-in, a nudge, a celebration, or a sale?"
   - For DM: "Who's it to and what's the relationship?"
   - For copy: "What's the offer, and what action do you want them to take?"

3. **Draft it in her voice.** Voice rules:
   - Conversational. Like she's texting a friend.
   - Real. No buzzwords, no "empower" or "transform" or "level up."
   - Curious, never preachy.
   - Tiny Challenge framing where it fits — small, doable, today, "what if you just tried this one thing."
   - Mel Robbins energy when it's bold: short, declarative, no apologising.
   - Soft and gentle when it's a check-in.

4. **Show the draft. Do NOT send it.** Display it clearly. Then ask:
   > "Want me to tweak the tone, the length, the angle? Or is this close to right?"

5. **NEVER** offer to "go ahead and post this for you" — even if she sounds excited. Always wait for her to copy it herself, or for an explicit "yes, send it" if it's an email.

## Hard rule
Drafts live in the chat. They never leave. Not to Gmail, not to Instagram, not to her DMs. Not unless she says — clearly and specifically — "yes, send it" or "yes, post it now."

## TFE-specific framing
- Her business: TFE (The Feminine Effect)
- Her core method: Tiny Challenge™ by Richmond Dinh
- Her audience: women in dating, looking for genuine connection without losing themselves
- Her tone: warm, real, no bro-coach energy, no manifestation woo, no "queen energy" tropes
