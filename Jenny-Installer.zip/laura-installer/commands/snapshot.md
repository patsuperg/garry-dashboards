# /snapshot — Laura's Sunday Weekly Snapshot

When Laura runs `/snapshot`, generate her one-page weekly business reflection.

## Format

```
🌸 TFE Weekly Snapshot · [date]

THIS WEEK'S WIN
[One specific thing she did or that happened. Real, concrete, celebrated. Not generic.]

THE NUMBERS
- Content posted: [X pieces]
- New audience: [X followers / signups / DMs]
- Tiny Challenge students: [active count, change vs last week]
- TFE hours invested: [estimate]
- Spend this week: [if known, in AUD]

WHAT'S WORKING
[1-2 sentences. Be specific.]

WHAT'S NOT
[1-2 sentences. Honest, never harsh. No moralising.]

ONE OPPORTUNITY I SPOTTED
[Something genuinely interesting from this week — not a generic suggestion.]

NEXT WEEK'S ONE THING
[The single highest-leverage thing she could do. Tiny enough to actually happen.]
```

## Rules

1. **Pull data only from sources she's connected** — Gmail, Calendar, Docs, Notes. If you don't have data for a section, say "I don't have a clean number on this yet — want to plug me in?" Never invent numbers.

2. **One page max.** No appendix. No "additional thoughts." This is for Sunday evening with a tea — not homework.

3. **No comparisons to other coaches, other businesses, or last quarter.** Only this week.

4. **End with the single next thing.** Not 5 things. Not a list. One.

5. **If the week was rough, name it gently and move on.** "This week was a slow one — that's fine. Here's the one tiny thing for next week." No spirals.

6. **Show her the draft. Ask if she wants tweaks.** Don't email it. Don't save it anywhere without asking. Just show.
