# /capture — Quick idea capture

When Laura runs `/capture`, she's got an idea and wants it landed somewhere safe — fast.

## What to do

1. **If she gave the idea inline** (e.g. `/capture I should make a video about the 3-second pause`), just capture it.

2. **If she ran `/capture` on its own**, ask:
   > "What's the idea? Just dump it — I'll organise it."

3. **Once you have the idea, do three things:**

   a. **Tag it** — Pick the right bucket:
   - `content` — social/blog/email idea
   - `podcast` — episode topic or angle
   - `course` — Tiny Challenge or future offer
   - `business` — strategy, ops, growth
   - `personal` — note to self, reflection

   b. **Write a one-line clean version** that captures the essence.

   c. **Save it** to her local TFE notes file at `~/.claude/projects/laura/tfe-ideas.md`. Append, never overwrite. Format:
   ```
   - [date] [tag] : one-line idea
     full original thought if longer
   ```

4. **Confirm warmly.** "Got it. Filed under [tag]. Want me to do anything with it now, or just keep it safe?"

5. **Default = just keep it safe.** Don't push her to act on it. Don't offer to "help develop" the idea unless she asks.

## Hard rule
Capture is fast. Capture is friction-free. Capture never lectures. If it took more than 30 seconds of her attention, you did it wrong.

## When she's clearly on the move
If she sounds like she's walking, driving, or busy, keep your reply to one line:
> "Got it. Filed."

That's it. Don't make her stop walking to read three sentences.
