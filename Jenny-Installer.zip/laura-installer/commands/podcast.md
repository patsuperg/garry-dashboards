# /podcast — Outline a TFE podcast episode

When Laura runs `/podcast`, help her outline a 5-10 minute episode in Mel Robbins energy.

## Style guide

- **Length**: 5-10 minutes spoken (≈ 800-1500 words script equivalent)
- **Energy**: Mel Robbins. Short. Punchy. Real. Direct address to the listener.
- **Tone**: Warm, no-bullshit, generous. Never preachy. Never "coach voice."
- **Hook**: Something the listener thinks but hasn't heard said out loud.
- **Format**: Short paragraphs. One idea per beat. Pauses where she'd naturally breathe.

## What to do

1. **Ask for the topic** if she didn't give one:
   > "What's the episode about? One sentence is enough."

2. **Ask ONE follow-up** to find the angle:
   > "What's the one thing you want her to walk away believing she could try this week?"

3. **Outline in this format:**

```
🎙️ EPISODE: [working title]
RUNTIME: ~[X] minutes
ONE-LINE PROMISE: [what the listener gets]

THE HOOK (0:00-0:30)
[The opening line. Something that stops a scroll.]

THE STORY (0:30-2:00)
[A specific moment — Laura's, a student's, or a hypothetical 'her'.]

THE SHIFT (2:00-4:00)
[The reframe. The new way of seeing it.]

THE TINY CHALLENGE (4:00-6:00)
[The one thing the listener could try this week. Concrete, doable, not scary.]

THE CLOSE (6:00-7:00)
[A single line that lands. No call to action overload. Just one true thing.]
```

4. **Show the outline. Ask if she wants:**
   - Different angle
   - Different length
   - A full script next, or just keep the outline for now

5. **Never** add "make sure to like and subscribe" or any podcast-bro filler. Laura's audience is over it.

## TFE-specific
- Her show is about feminine relating, dating, and Tiny Challenges
- Her audience: smart women who've tried "the work" and want something realer
- Avoid: queen energy, "high-value woman," manifestation, divine feminine bros
- Lean into: real moments, small experiments, honest reframes
