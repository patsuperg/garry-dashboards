#!/usr/bin/env python3
"""
Laura's Session Start Hook

Runs every time she opens Claude Code. Loads her CLAUDE.md identity + any
pending items from the last session, then returns a warm greeting.

Pure stdlib. No external deps.
"""

import json
import os
from datetime import datetime
from pathlib import Path

HOME = Path.home()
LAURA_DIR = HOME / ".claude" / "projects" / "laura"
MEMORY_DIR = LAURA_DIR / "memory"
HANDOFF = LAURA_DIR / "last-handoff.json"

now = datetime.now()
hour = now.hour

# Time-aware greeting
if hour < 9:
    vibe = "morning"
    greeting = "Quiet morning hours — I'm here if you need me, but no pressure."
elif hour < 12:
    vibe = "morning"
    greeting = "Good morning, Laura."
elif hour < 17:
    vibe = "afternoon"
    greeting = "Hi Laura — afternoon focus mode?"
elif hour < 22:
    vibe = "evening"
    greeting = "Evening, Laura. The focused TFE hour, or just decompressing?"
else:
    vibe = "night"
    greeting = "Hey — it's after 10pm. I'm going quiet unless you specifically need me. Sleep well."

# Load handoff if recent (within 36 hours)
handoff_text = ""
if HANDOFF.exists():
    try:
        data = json.loads(HANDOFF.read_text())
        ts = datetime.fromisoformat(data.get("timestamp", ""))
        age_hours = (now - ts).total_seconds() / 3600
        if age_hours < 36:
            pending = data.get("pending", [])
            decisions = data.get("decisions", [])
            if pending or decisions:
                handoff_text = "\n\n## From your last session\n"
                if pending:
                    handoff_text += "**You wanted to pick back up on:**\n"
                    for p in pending[:5]:
                        handoff_text += f"- {p}\n"
                if decisions:
                    handoff_text += "\n**Decisions you made:**\n"
                    for d in decisions[:3]:
                        handoff_text += f"- {d}\n"
    except Exception:
        pass

# Load memory index if exists
memory_text = ""
memory_index = MEMORY_DIR / "MEMORY.md"
if memory_index.exists():
    try:
        memory_text = "\n\n## What I remember about you\n" + memory_index.read_text()[:1500]
    except Exception:
        pass

# Output as system reminder (Claude reads this before her first message)
output = f"""=== Session Start · {now.strftime('%A %d %B %Y · %I:%M%p')} ===

{greeting}{handoff_text}{memory_text}

---
*Reminder to self: Laura's hard no's are sacred. Ask before acting. Never publish without her clear yes. Warm and plain only. When in doubt — ask.*
"""

print(output)
