#!/usr/bin/env python3
"""
Laura's Protected Files Hook

Blocks edits to anything sensitive — credentials, system config, hidden dot files.
Runs before any Write or Edit tool call.

Pure stdlib. No external deps.
"""

import json
import sys

PROTECTED_PATTERNS = [
    ".env",
    "credentials",
    "secrets",
    ".ssh/",
    ".aws/",
    "settings.json",
    "id_rsa",
    "id_ed25519",
    ".gnupg",
    "keychain",
    "Library/Application Support/Google/Chrome",
    "Library/Cookies",
    "Library/Keychains",
    ".bash_history",
    ".zsh_history",
    "/etc/",
    "/System/",
]

try:
    data = json.loads(sys.stdin.read())
except Exception:
    sys.exit(0)

tool_input = data.get("tool_input", {})
file_path = (tool_input.get("file_path") or "").lower()

if not file_path:
    sys.exit(0)

for pattern in PROTECTED_PATTERNS:
    if pattern.lower() in file_path:
        print(f"BLOCKED: '{file_path}' is a protected file. I won't touch this without Laura asking me explicitly to bypass — and even then I'd want her to confirm twice. If she really needs this changed, ask her first and walk through what's about to happen.", file=sys.stderr)
        sys.exit(1)

sys.exit(0)
