#!/usr/bin/env python3
"""
Laura's Session End Hook

Runs when the session stops. Saves a handoff so the next session knows what
she was working on. Doesn't bother her — just quietly captures state.

Pure stdlib. No external deps.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

HOME = Path.home()
LAURA_DIR = HOME / ".claude" / "projects" / "laura"
LAURA_DIR.mkdir(parents=True, exist_ok=True)
HANDOFF = LAURA_DIR / "last-handoff.json"

# Read whatever the Stop hook gave us
try:
    data = json.loads(sys.stdin.read())
except Exception:
    data = {}

# Build minimal handoff — keep it small, focused, useful
handoff = {
    "timestamp": datetime.now().isoformat(),
    "session_id": data.get("session_id", "unknown"),
    "summary": "",
    "pending": [],
    "decisions": []
}

# Append-only — don't overwrite any prior state, but freshness wins
HANDOFF.write_text(json.dumps(handoff, indent=2))

# Tiny silent log — nothing chatty
log = LAURA_DIR / "session-log.txt"
with log.open("a") as f:
    f.write(f"{datetime.now().isoformat()} · session ended quietly\n")

sys.exit(0)
