#!/usr/bin/env python3
"""
Jenny's Economy Router

Routes Laura's tasks between local Ollama (free) and Claude (Pro credits).
Saves ~75% of credits by handling small stuff locally.

Usage:
  python3 jenny-router.py "summarize this article: ..."
  python3 jenny-router.py --force-claude "draft a TFE email"

Pure stdlib. No external deps.
"""

import json
import sys
import urllib.request
import urllib.error

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.1:8b"
OLLAMA_TIMEOUT = 25

# Keywords that should always go to local Ollama (cheap, fast)
LOCAL_KEYWORDS = [
    "summarize", "summarise", "summary",
    "format", "tidy", "clean up", "fix the formatting",
    "list", "bullet", "bullets",
    "what is", "what's", "define",
    "translate",
    "shorter", "shorten",
    "longer", "extend",
    "rephrase", "reword",
    "spell check", "grammar",
    "convert",
    "extract",
    "count",
    "tag", "categorise",
]

# Keywords that should go to Claude Pro (heavy creative work)
CLAUDE_KEYWORDS = [
    "draft", "write", "compose",
    "tfe", "tiny challenge",
    "podcast", "episode",
    "email to", "dm to",
    "social post", "instagram", "linkedin",
    "snapshot", "weekly",
    "strategy", "plan",
    "voice", "tone",
    "creative", "story",
]


def classify(prompt: str) -> str:
    """Return 'local' or 'claude' based on the prompt."""
    p = prompt.lower()
    for kw in CLAUDE_KEYWORDS:
        if kw in p:
            return "claude"
    for kw in LOCAL_KEYWORDS:
        if kw in p:
            return "local"
    # Default: short prompts → local, long/complex → claude
    if len(prompt) < 200:
        return "local"
    return "claude"


def call_ollama(prompt: str) -> str | None:
    """Call local Ollama. Returns None on failure."""
    body = json.dumps({
        "model": OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
    }).encode("utf-8")

    req = urllib.request.Request(
        OLLAMA_URL,
        data=body,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("response", "").strip()
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def main() -> int:
    args = sys.argv[1:]
    force_claude = "--force-claude" in args
    if force_claude:
        args.remove("--force-claude")

    if not args:
        print("Usage: jenny-router.py [--force-claude] '<prompt>'", file=sys.stderr)
        return 1

    prompt = " ".join(args)
    target = "claude" if force_claude else classify(prompt)

    if target == "local":
        result = call_ollama(prompt)
        if result:
            print(result)
            return 0
        # Fallback to Claude if Ollama fails
        print("[Jenny: local brain hiccupped, falling back to Claude]", file=sys.stderr)
        target = "claude"

    if target == "claude":
        # In real use, Claude Code handles this — the router just signals
        # "this needs Claude" to the calling context. For standalone use,
        # we print the prompt back so the calling shell can pipe it to claude.
        print(f"[ROUTE:claude] {prompt}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
