#!/bin/bash
# ═══════════════════════════════════════════════
#   JENNY — Laura's Personal Assistant Installer
#   Built by Garry · April 2026
# ═══════════════════════════════════════════════
#
# This is a one-click installer for Laura's AI assistant "Jenny".
# It installs everything she needs and configures it for her.
#
# Designed to be double-clicked. No terminal commands required.

set -e
trap 'echo ""; echo "❌ Something went wrong. Text Pat — he can fix it in minutes."; echo ""; read -p "Press Enter to close this window..."; exit 1' ERR

# ─── Colors ───────────────────────────────────
PINK='\033[38;5;217m'
ROSE='\033[38;5;175m'
SAGE='\033[38;5;108m'
GOLD='\033[38;5;221m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

# ─── Find script directory ────────────────────
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# ─── Banner ───────────────────────────────────
clear
echo ""
echo -e "${PINK}${BOLD}"
echo "   🌸  ╔═══════════════════════════════════╗  🌸"
echo "       ║                                   ║"
echo "       ║          MEET  JENNY              ║"
echo "       ║   Laura's personal copilot        ║"
echo "       ║                                   ║"
echo "       ╚═══════════════════════════════════╝"
echo -e "${RESET}"
echo ""
echo -e "${ROSE}   Hi Laura! I'm setting up Jenny for you.${RESET}"
echo -e "${DIM}   This will take 5-10 minutes. You can leave it running.${RESET}"
echo ""
echo -e "${DIM}   At one point I'll ask for your Mac password —${RESET}"
echo -e "${DIM}   that's normal, it's how Mac installs new software.${RESET}"
echo ""
echo -e "${SAGE}   Starting in 3 seconds...${RESET}"
sleep 3

# ─── Helper functions ─────────────────────────
step() {
  echo ""
  echo -e "${PINK}${BOLD}▸ $1${RESET}"
}

ok() {
  echo -e "${SAGE}  ✓ $1${RESET}"
}

info() {
  echo -e "${DIM}  $1${RESET}"
}

# ─── Detect Apple Silicon vs Intel ────────────
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
  BREW_PREFIX="/opt/homebrew"
else
  BREW_PREFIX="/usr/local"
fi
export PATH="$BREW_PREFIX/bin:$PATH"

# ─── Step 1: Homebrew ─────────────────────────
step "Step 1 of 7 — Checking Homebrew (the package manager)"
if ! command -v brew &> /dev/null; then
  info "Installing Homebrew. You'll be asked for your Mac password in a sec."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" < /dev/null
  # Add brew to PATH for current session
  if [ -f "$BREW_PREFIX/bin/brew" ]; then
    eval "$($BREW_PREFIX/bin/brew shellenv)"
  fi
  ok "Homebrew installed"
else
  ok "Homebrew already there"
fi

# ─── Step 2: Node.js ──────────────────────────
step "Step 2 of 7 — Checking Node.js"
if ! command -v node &> /dev/null; then
  info "Installing Node.js (this takes about a minute)..."
  brew install node
  ok "Node.js installed"
else
  ok "Node.js already there ($(node -v))"
fi

# ─── Step 3: Ollama (free local brain) ────────
step "Step 3 of 7 — Installing Ollama (Jenny's free local brain)"
if ! command -v ollama &> /dev/null; then
  info "Installing Ollama..."
  brew install ollama
  ok "Ollama installed"
else
  ok "Ollama already there"
fi

# Start Ollama service in background
info "Starting Ollama service..."
brew services start ollama &> /dev/null || ollama serve &> /dev/null &
sleep 3

# ─── Step 4: Pull the model ───────────────────
step "Step 4 of 7 — Downloading Jenny's brain (~5GB, this is the longest part)"
if ollama list 2>/dev/null | grep -q "llama3.1:8b"; then
  ok "Brain already downloaded"
else
  info "This takes 5-15 minutes depending on your internet."
  info "You can grab a tea ☕ — I'll be here when you get back."
  ollama pull llama3.1:8b
  ok "Brain downloaded"
fi

# ─── Step 5: Claude Code ──────────────────────
step "Step 5 of 7 — Installing Claude Code"
if ! command -v claude &> /dev/null; then
  info "Installing Claude Code via npm..."
  npm install -g @anthropic-ai/claude-code 2>&1 | tail -5
  ok "Claude Code installed"
else
  ok "Claude Code already there"
fi

# ─── Step 6: Set up Jenny's files ─────────────
step "Step 6 of 7 — Installing Jenny's personality and commands"

# Create directory structure
mkdir -p "$HOME/.claude/hooks"
mkdir -p "$HOME/.claude/commands"
mkdir -p "$HOME/.claude/router"
mkdir -p "$HOME/.claude/projects/laura/memory"
ok "Directories created"

# Backup any existing CLAUDE.md
if [ -f "$HOME/CLAUDE.md" ]; then
  cp "$HOME/CLAUDE.md" "$HOME/CLAUDE.md.backup-$(date +%Y%m%d-%H%M%S)"
  info "Backed up your old CLAUDE.md (just in case)"
fi

# Backup any existing settings.json
if [ -f "$HOME/.claude/settings.json" ]; then
  cp "$HOME/.claude/settings.json" "$HOME/.claude/settings.json.backup-$(date +%Y%m%d-%H%M%S)"
  info "Backed up your old settings.json (just in case)"
fi

# Install Jenny's identity (CLAUDE.md)
cp "$SCRIPT_DIR/identity.md" "$HOME/CLAUDE.md"
ok "Jenny's personality installed"

# Install Claude Code settings
cp "$SCRIPT_DIR/config.json" "$HOME/.claude/settings.json"
ok "Claude Code configured"

# Install hooks
cp "$SCRIPT_DIR/hooks/session-start.py" "$HOME/.claude/hooks/"
cp "$SCRIPT_DIR/hooks/protected-files.py" "$HOME/.claude/hooks/"
cp "$SCRIPT_DIR/hooks/session-end.py" "$HOME/.claude/hooks/"
chmod +x "$HOME/.claude/hooks/"*.py
ok "Hooks installed (these protect you and remember context)"

# Install slash commands
cp "$SCRIPT_DIR/commands/"*.md "$HOME/.claude/commands/"
ok "6 magic commands installed (/morning /draft /snapshot /capture /podcast /help)"

# Install router
cp "$SCRIPT_DIR/router/jenny-router.py" "$HOME/.claude/router/"
chmod +x "$HOME/.claude/router/jenny-router.py"
ok "Economy router installed (saves your Pro credits)"

# Seed memory with a welcome note
cat > "$HOME/.claude/projects/laura/memory/MEMORY.md" << 'MEMEND'
# Jenny's Memory of Laura

## What I know so far
- Laura is building TFE (The Feminine Effect) — dating coaching using Tiny Challenge framework
- She has a 9-5 day job in Melbourne
- Married to Pat — her marriage is the priority
- Bedtime is 10pm — I go quiet then
- She picked my name (Jenny) on April 8, 2026

## Things I'll remember as we go
- (this section grows over time)
MEMEND
ok "Jenny's memory seeded"

# ─── Step 7: Final touches ────────────────────
step "Step 7 of 7 — Final touches"

# Pre-warm Ollama with a quick test
info "Waking up Jenny's local brain..."
curl -s -m 5 http://localhost:11434/api/tags > /dev/null 2>&1 && ok "Local brain online" || info "Local brain will wake up on first use"

# ─── Done! ────────────────────────────────────
echo ""
echo ""
echo -e "${GOLD}${BOLD}"
echo "   🌸 ═══════════════════════════════════ 🌸"
echo "                                              "
echo "          ✨  JENNY IS READY  ✨              "
echo "                                              "
echo "   🌸 ═══════════════════════════════════ 🌸"
echo -e "${RESET}"
echo ""
echo -e "${ROSE}${BOLD}   What now, Laura?${RESET}"
echo ""
echo -e "${ROSE}   1.${RESET} Open the app called ${BOLD}Terminal${RESET} (or any terminal)"
echo -e "${ROSE}   2.${RESET} Type: ${BOLD}claude${RESET} and press Enter"
echo -e "${ROSE}   3.${RESET} Log into your Claude Pro account when it asks (one time only)"
echo -e "${ROSE}   4.${RESET} Say hi to Jenny — she'll introduce herself"
echo ""
echo -e "${SAGE}   Try this first: type ${BOLD}/morning${RESET}${SAGE} once you're in.${RESET}"
echo ""
echo -e "${DIM}   If anything feels off, text Pat. He's got Garry on standby.${RESET}"
echo ""
echo ""

# Open the design page in Safari so she can see Jenny's overview
open "https://patsuperg.github.io/garry-dashboards/laura-design.html" 2>/dev/null || true

read -p "Press Enter to close this window..."
