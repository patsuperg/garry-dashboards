═══════════════════════════════════════════════
   JENNY — Laura's Personal Assistant
   Installation Guide
═══════════════════════════════════════════════

Hi Laura! 🌸

This is Jenny — your new copilot. Here's how to install
her on your Mac. The whole thing takes 5-10 minutes and
you only have to do it once.

──────────────────────────────────────────────
HOW TO INSTALL
──────────────────────────────────────────────

1. Find the file called "Install-Jenny.command" in this
   folder.

2. RIGHT-CLICK it (two-finger tap on trackpad) and choose
   "Open" from the menu.

   ⚠️ A box will pop up saying something like "macOS
   cannot verify the developer." Click "Open" anyway —
   this is normal because Pat made it just for you.

3. A black Terminal window opens and starts installing.
   You'll see colorful text scrolling. That's Jenny
   getting ready. Just leave it running.

4. At one point it will ask for your Mac password. Type
   it in and press Enter. (Nothing will appear as you
   type — that's normal too. Mac doesn't show passwords.)

5. Wait for the message "🌸 JENNY IS READY 🌸" to appear.
   That's it. You can close the Terminal window.

──────────────────────────────────────────────
HOW TO TALK TO JENNY
──────────────────────────────────────────────

After installing, you'll have a new app called
"Claude Code" in your Applications folder.

1. Open Claude Code (or just type "claude" in the
   Terminal — Jenny will show you the easy way the
   first time you open her).

2. The first time, she'll ask you to log into your
   Claude Pro account. Just do the browser popup once
   and you're done forever.

3. Say hi to her. She'll introduce herself.

──────────────────────────────────────────────
JENNY'S COMMANDS (the magic words)
──────────────────────────────────────────────

Type any of these to give her a quick task:

  /morning   — She'll check in and offer 2-3 tiny
               things she can help with today.

  /draft     — She'll draft TFE content for you in
               your voice. (She'll ALWAYS show you
               first. Nothing gets sent without
               your clear yes.)

  /snapshot  — She'll build your Sunday weekly
               business snapshot.

  /capture   — Quick idea capture. Speak/type an
               idea, she'll file it.

  /podcast   — Outline a 5-10 minute episode in
               your voice.

  /help      — When you don't know what to ask.
               She'll re-introduce herself and offer
               3 small things to try.

You can also just talk to her normally! She's smart
and warm and gets it.

──────────────────────────────────────────────
WHAT JENNY WILL NEVER DO
──────────────────────────────────────────────

• Send anything without your clear "yes, send it"
• Post anything without your clear "yes, post it"
• Make you feel dumb, behind, or overwhelmed
• Use corporate or formal tone
• Give you advice you didn't ask for
• Act before asking

When in doubt, she ALWAYS asks first.

──────────────────────────────────────────────
IF SOMETHING GOES WRONG
──────────────────────────────────────────────

Just text Pat. He's got Garry on standby and they'll
fix it for you in minutes. Don't worry about it.

──────────────────────────────────────────────

Welcome aboard. Jenny's been waiting for you. 💛

— Pat & Garry
